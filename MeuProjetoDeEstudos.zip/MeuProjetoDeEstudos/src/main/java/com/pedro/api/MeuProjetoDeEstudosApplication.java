package com.pedro.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeuProjetoDeEstudosApplication {

	public static void main(String[] args) {
		SpringApplication.run(MeuProjetoDeEstudosApplication.class, args);
	}

}
